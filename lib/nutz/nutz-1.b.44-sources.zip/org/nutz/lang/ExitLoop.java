package org.nutz.lang;

/**
 * 退出循环
 * 
 * @author zozoh(zozohtnt@gmail.com)
 */
@SuppressWarnings("serial")
public class ExitLoop extends RuntimeException {}
