package org.nutz.lang;

/**
 * 继续循环，如果正在递归，则停止继续递归
 * 
 * @author zozoh(zozohtnt@gmail.com)
 */
@SuppressWarnings("serial")
public class ContinueLoop extends RuntimeException {}
