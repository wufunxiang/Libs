package org.nutz.dao.sql;

public enum SqlType {

	SELECT, DELETE, TRUNCATE, UPDATE, INSERT, CREATE, DROP, RUN, ALTER, OTHER

}
