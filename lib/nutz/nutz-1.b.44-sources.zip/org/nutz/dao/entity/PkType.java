package org.nutz.dao.entity;

public enum PkType {

	UNKNOWN, ID, NAME, COMPOSITE

}
